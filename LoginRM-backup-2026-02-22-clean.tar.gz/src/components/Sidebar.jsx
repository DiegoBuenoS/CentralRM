// Sidebar

import React from 'react';
import {
  ArrowLeftOnRectangleIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  MoonIcon,
  ReceiptPercentIcon,
  SunIcon,
} from '@heroicons/react/24/outline';
import { useTheme } from '../hooks/useTheme';
import {
  Sidebar as SidebarRoot,
  SidebarHeader,
  SidebarFooter,
  SidebarContent,
  SidebarGroup,
  SidebarTrigger,
  useSidebar,
} from './ui/sidebar';

const travelMenu = [
  {
    id: 'despesas-viagens',
    label: 'Despesas com Viagens',
    icon: ReceiptPercentIcon,
    path: '/despesas-viagens',
  },
];

const Sidebar = ({ onLogout, currentPage, onNavigate }) => {
  const { isDarkMode, toggleTheme } = useTheme();
  const { collapsed } = useSidebar();

  return (
    <SidebarRoot className="fixed left-0 top-0 z-50 overflow-x-hidden border-r-2 border-blue-100 bg-gradient-to-b from-white to-blue-50/60 shadow-md dark:border-graphite-700 dark:bg-graphite-950">
      <SidebarHeader className="flex h-16 items-center justify-between px-3">
        {!collapsed && (
          <div className="flex items-center space-x-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-blue-700 dark:bg-graphite-200">
              <span className="text-sm font-semibold text-white dark:text-graphite-900">RM</span>
            </div>
            <div>
              <span className="text-[15px] font-semibold leading-none tracking-tight">RM Despesas</span>
              <p className="text-[11px] tracking-tight text-graphite-600 dark:text-graphite-300">Foco em viagens</p>
            </div>
          </div>
        )}
        <SidebarTrigger
          className="rounded-md p-2 text-graphite-700 transition-colors hover:bg-blue-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-300 dark:text-graphite-200 dark:hover:bg-graphite-800"
          title={collapsed ? 'Expandir menu' : 'Recolher menu'}
        >
          {collapsed ? (
            <ChevronRightIcon className="h-5 w-5" />
          ) : (
            <ChevronLeftIcon className="h-5 w-5" />
          )}
        </SidebarTrigger>
      </SidebarHeader>

      <SidebarContent className="py-3">
        {!collapsed && (
          <div className="px-2.5 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-graphite-500 dark:text-graphite-400">
            Módulo
          </div>
        )}
        <SidebarGroup className="space-y-1 px-2">
          {travelMenu.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item)}
                className={`
                  w-full flex items-center py-2 rounded-md
                  ${collapsed ? 'justify-center px-0' : 'space-x-2.5 px-2.5'}
                  transition-all duration-200 ring-1 ring-inset
                  ${
                    isActive
                      ? 'bg-blue-700 text-white ring-blue-700 dark:bg-graphite-800 dark:text-graphite-50 dark:ring-graphite-600'
                      : 'text-graphite-800 hover:bg-blue-50 hover:text-blue-900 ring-transparent dark:text-graphite-300 dark:hover:bg-graphite-800 dark:hover:text-graphite-50'
                  }
                `}
                title={collapsed ? item.label : ''}
              >
                <Icon className="h-[18px] w-[18px] flex-shrink-0" />
                {!collapsed && (
                  <span className="flex-1 text-left text-[13px] font-medium tracking-tight">
                    {item.label}
                  </span>
                )}
              </button>
            );
          })}
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-3">
        <button
          onClick={toggleTheme}
          className={`w-full flex items-center py-2 rounded-md
                     ${collapsed ? 'justify-center px-0' : 'space-x-2.5 px-2.5'}
                     text-graphite-800 hover:bg-blue-50 hover:text-blue-900
                     dark:text-graphite-300 dark:hover:bg-graphite-800 dark:hover:text-graphite-50
                     transition-all duration-200 mb-2`}
          title={collapsed ? 'Tema' : ''}
          aria-pressed={isDarkMode}
        >
          {isDarkMode ? (
            <SunIcon className="h-5 w-5 flex-shrink-0" />
          ) : (
            <MoonIcon className="h-5 w-5 flex-shrink-0" />
          )}
          {!collapsed && <span className="font-medium">{isDarkMode ? 'Tema claro' : 'Tema escuro'}</span>}
        </button>
        <button
          onClick={onLogout}
          className={`w-full flex items-center py-2 rounded-md
                     ${collapsed ? 'justify-center px-0' : 'space-x-2.5 px-2.5'}
                     text-graphite-800 hover:bg-blue-50 hover:text-blue-900
                     dark:text-graphite-300 dark:hover:bg-graphite-800 dark:hover:text-graphite-50
                     transition-all duration-200`}
          title={collapsed ? 'Sair' : ''}
        >
          <ArrowLeftOnRectangleIcon className="h-5 w-5 flex-shrink-0" />
          {!collapsed && <span className="font-medium">Sair</span>}
        </button>
      </SidebarFooter>
    </SidebarRoot>
  );
};

export default Sidebar;
