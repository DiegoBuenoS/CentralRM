// App

import React, { Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { isAuthenticated } from './services';
import './index.css';

const LoginPage = React.lazy(() => import('./pages/LoginPage'));
const DashboardPage = React.lazy(() => import('./pages/DashboardPage'));
const TRAVEL_FOCUS_PATH = '/despesas-viagens';
const TRAVEL_FOCUS_PAGE = 'despesas-viagens';
const TEMP_DISABLED_MODULE_PATHS = [
  '/dashboard',
  '/tarefas',
  '/pedidos',
  '/notas-fiscais',
  '/relatorios',
  '/configuracoes',
  '/cadastros',
  '/cadastros/estoque',
  '/cadastros/estoque/produtos',
  '/cadastros/estoque/local',
  '/cadastros/financeiro',
  '/cadastros/financeiro/clientes',
  '/cadastros/financeiro/contas',
  '/cadastros/est-compras-fat',
  '/cadastros/globais',
];

// Auth guard
const ProtectedRoute = ({ children }) => {
  return isAuthenticated() ? children : <Navigate to="/" replace />;
};

// Public guard
const PublicRoute = ({ children }) => {
  return !isAuthenticated() ? children : <Navigate to={TRAVEL_FOCUS_PATH} replace />;
};

const TravelFocusRoute = () => (
  <ProtectedRoute>
    <DashboardPage initialPage={TRAVEL_FOCUS_PAGE} />
  </ProtectedRoute>
);

const TravelFocusRedirectRoute = () => (
  <ProtectedRoute>
    <Navigate to={TRAVEL_FOCUS_PATH} replace />
  </ProtectedRoute>
);

function App() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen grid place-items-center bg-mist text-sm text-graphite-600">
          Carregando...
        </div>
      }
    >
      <Routes>
        <Route
          path="/"
          element={
            <PublicRoute>
              <LoginPage />
            </PublicRoute>
          }
        />

        <Route
          path={TRAVEL_FOCUS_PATH}
          element={<TravelFocusRoute />}
        />

        {TEMP_DISABLED_MODULE_PATHS.map((path) => (
          <Route
            key={path}
            path={path}
            element={<TravelFocusRedirectRoute />}
          />
        ))}

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

export default App;
