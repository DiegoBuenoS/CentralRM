-- Banco recomendado para produção: PostgreSQL
-- Este script cria a tabela principal de solicitações de viagem.

CREATE TABLE IF NOT EXISTS travel_requests (
  request_id TEXT PRIMARY KEY,
  idempotency_key TEXT UNIQUE NOT NULL,
  requester TEXT NOT NULL,
  tipo_solicitacao TEXT NOT NULL,
  origem TEXT NOT NULL,
  destino TEXT NOT NULL,
  periodo_inicio DATE NOT NULL,
  periodo_fim DATE NOT NULL,
  km_estimado NUMERIC(12,2) NOT NULL DEFAULT 0,
  centro_custo TEXT NULL,
  total_value NUMERIC(14,2) NOT NULL,
  numero_rm TEXT NULL,
  integration_status TEXT NOT NULL,
  retry_count INTEGER NOT NULL DEFAULT 0,
  last_error TEXT NULL,
  itens JSONB NOT NULL DEFAULT '[]'::jsonb,
  rateio JSONB NOT NULL DEFAULT '[]'::jsonb,
  anexos JSONB NOT NULL DEFAULT '[]'::jsonb,
  observacao TEXT NOT NULL DEFAULT '',
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  integrated_at TIMESTAMPTZ NULL
);

CREATE INDEX IF NOT EXISTS idx_travel_requests_created_at ON travel_requests (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_travel_requests_status ON travel_requests (integration_status);
CREATE INDEX IF NOT EXISTS idx_travel_requests_requester ON travel_requests (requester);
